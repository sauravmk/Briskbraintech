<?php

return [

    'model' => \RyanChandler\Comments\Models\Comment::class,

    /** @phpstan-ignore-next-line */
    'user' => \App\Models\User::class,

];
