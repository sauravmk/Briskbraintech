<!DOCTYPE html>
<html>
<head>
    <title>Contact Form Submission</title>
</head>
<body>
    <h2>Contact Form Submission</h2>

    <p><strong>Name:</strong> <?php echo e($formData['name']); ?></p>
    <p><strong>Email:</strong> <?php echo e($formData['email']); ?></p>
    <p><strong>Contact No:</strong> <?php echo e($formData['contact']); ?></p>
    <p><strong>Subject:</strong> <?php echo e($formData['subject']); ?></p>

    <p><strong>Message:</strong></p>
    <p><?php echo e($formData['message']); ?></p>

    <p>Thank you for your submission.</p>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\saurav\briskbrain\resources\views/emails/contact-form-submitted.blade.php ENDPATH**/ ?>