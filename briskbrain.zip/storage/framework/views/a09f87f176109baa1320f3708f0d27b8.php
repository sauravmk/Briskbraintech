<?php $__env->startSection('title', 'Posts'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4">
    <div class="d-flex justify-content-between align-items-center">
        <h1 class="mt-4">Posts</h1>
        <div class="button-container">
            <a href="<?php echo e(url('admin/add-post')); ?>" class="btn btn-primary custom-button"  >Add Posts</a>
            <a href="<?php echo e(url('/blog')); ?>" class="btn btn-warning custom-button" target="_blank">View Posts</a>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                    <table id="myDataTable" class="table">
                        <thead>
                            <tr>
                                <th>Category</th>
                                <th>Name</th>
                                <th>Description</th>
                                <th>Status</th>
                                <th>Image</th>
                                <!-- Include the "tag" column -->
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($post->category->name); ?></td>
                                    <td><?php echo e($post->name); ?></td>
                                    <td><?php echo Illuminate\Support\Str::limit(strip_tags($post->description), 100); ?></td>
                                    <td><?php echo e($post->status); ?></td>
                                    <td>
                                        <?php if($post->image): ?>
                                            <img src="<?php echo e($post->image); ?>" alt="post Image"
                                                style="max-width: 100px; max-height: 100px;">
                                        <?php else: ?>
                                            No Image
                                        <?php endif; ?>
                                    </td>
                                    
                                    <td>
                                        <a href="<?php echo e(route('blogsingle', ['slug' => $post->slug])); ?>" class="btn btn-sm btn-info" target="_blank">
                                            <i class="fas fa-eye"></i> View
                                        </a>                                        
                                        <a href="<?php echo e(route('edit-post', $post->id)); ?>" class="btn btn-success">
                                            <i class="fas fa-edit"></i> Edit
                                        </a>                                      
                                        <form action="<?php echo e(route('delete-post', $post->id)); ?>" method="POST"
                                            style="display: inline;">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger"
                                                onclick="return confirm('Are you sure you want to delete this post?')">
                                                <i class="fas fa-trash"></i> Delete</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>  
                </div>
            </div>
        </div>
    </div>
    
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\saurav\briskbrain\resources\views/admin/posts/index.blade.php ENDPATH**/ ?>