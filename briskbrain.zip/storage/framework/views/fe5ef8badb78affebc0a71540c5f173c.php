<!DOCTYPE html>
<html>
<head>
    <title>Company Quote Request</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f7f7f7;
            margin: 0;
            padding: 0;
        }
        h1 {
            background-color: #333;
            color: #fff;
            padding: 10px;
            text-align: center;
        }
        p {
            background-color: #fff;
            padding: 10px;
            margin: 10px;
            border: 1px solid #ccc;
        }
    </style>
</head>
<body>
    <h1>Company Quote Request</h1>
    <p>Thank you for considering our services. We have received a quote request from the following company:</p>
    <p>Company Name: <?php echo e($name); ?></p>
    <p>Contact Email: <?php echo e($email); ?></p>
    <p>Company Website: <?php echo e($website); ?></p>
    <p>Request Description: <?php echo e($description); ?></p>
    
    <p>Please review the company's details provided and respond promptly with a customized quotation tailored to their requirements.</p>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\saurav\briskbrain\resources\views/emails/quote_request.blade.php ENDPATH**/ ?>