<?php $__env->startSection('title', 'Reviews'); ?>

<?php $__env->startSection('content'); ?>

    <div class="container-fluid px-4">
        <div class="d-flex justify-content-between align-items-center">
            <h1 class="mt-4">Reviews</h1>
            <a href="<?php echo e(url('/#dev')); ?>" class="btn btn-outline-primary page-primary">View Page</a>
            <a href="<?php echo e(url('admin/reviews/create')); ?>" class="btn btn-outline-warning">Add Reviews</a>
        </div><br>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <table id="myDataTable" class="table">
                        <thead>
                            <tr>
                                <th>Client Name</th>
                                <th>Designation</th>
                                <th>Review</th>
                                <th>Image</th>
                                <th>Actions</th>

                                 <!-- Include the "tag" column -->
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($review->client_name); ?></td>
                                    <td><?php echo e($review->designation); ?></td>
                                    <td><?php echo e($review->review_text); ?></td>
                                    <td>
                                        <?php if($review->image): ?>
                                            <img src="<?php echo e($review->image); ?>" alt="post Image"
                                                style="max-width: 100px; max-height: 100px;">
                                        <?php else: ?>
                                            No Image
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('reviews.edit', $review->id)); ?>"
                                            class="btn btn-outline-success">Edit</a>
                                        <form action="<?php echo e(route('reviews.destroy', $review->id)); ?>" method="POST"
                                            style="display: inline;">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-outline-danger"
                                                onclick="return confirm('Are you sure you want to delete this post?')">Delete</button>

                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\saurav\briskbrain\resources\views/admin/review/index.blade.php ENDPATH**/ ?>