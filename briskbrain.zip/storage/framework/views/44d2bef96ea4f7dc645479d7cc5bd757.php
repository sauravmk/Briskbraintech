

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1 style="margin-top: 34px;  margin-bottom: 34px;">Page Metadata</h1>
        <table id="myDataTable" class="table table-bordered">
            <thead>
                <tr>
                    <th>Page Name</th>
                    <th>Title</th>
                    <th>Meta Title</th>
                    <th>Meta Description</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $pageMetadata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $metadata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($pageNames[$metadata->page_name]); ?></td>
                        <td><?php echo e($metadata->title); ?></td>
                        <td><?php echo e($metadata->meta_title); ?></td>
                        <td><?php echo e($metadata->meta_description); ?></td>
                        <td>
                            <a href="<?php echo e(route('admin.page-metadata.edit', $metadata->id)); ?>" class="btn btn-primary">Edit</a>
                            <form action="<?php echo e(route('admin.page-metadata.destroy', $metadata->id)); ?>" method="POST"
                                style="display: inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger"
                                    onclick="return confirm('Are you sure you want to delete this page metadata?')">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <a href="<?php echo e(route('admin.page-metadata.create')); ?>" class="btn btn-success">Create Page Metadata</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\saurav\briskbrain\resources\views/admin/page-metadata/index.blade.php ENDPATH**/ ?>