<div id="layoutSidenav_nav">
    <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
        <div class="sb-sidenav-menu">
            <div class="nav">
                <div class="sb-sidenav-menu-heading">Core</div>
                <a class="nav-link <?php echo e(Request::is('admin/dashboard') ? 'active' : ''); ?>" href="<?php echo e(url('admin/dashboard')); ?>">
                    <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                    Dashboard
                </a>
                <div class="sb-sidenav-menu-heading">Interface</div>
                <a class="nav-link <?php echo e(Request::is('admin/category') || Request::is('admin/edit-category/*') || Request::is('admin/add-category') ? 'collapse active' : 'collapsed'); ?>"
                    href="#" data-bs-toggle="collapse" data-bs-target="#collapseLayouts" aria-expanded="false"
                    aria-controls="collapseLayouts">
                    <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
                    Category
                    <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                </a>
                <div class="collapse <?php echo e(Request::is('admin/category') || Request::is('admin/dd-category') || Request::is('admin/edit-category/*')
                    ? 'show'
                    : ''); ?>"
                    id="collapseLayouts" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                    <nav class="sb-sidenav-menu-nested nav">
                        <a class="nav-link <?php echo e(Request::is('admin/add-category') ? 'active' : ''); ?>"
                            href="<?php echo e(url('admin/add-category')); ?>">Add Category</a>
                        <a class="nav-link <?php echo e(Request::is('admin/category') || Request::is('admin/edit-category/*') ? 'active' : ''); ?>"
                            href="<?php echo e(url('admin/category')); ?>">View Category</a>
                    </nav>
                </div>
                <a class="nav-link <?php echo e(Request::is('admin/posts') || Request::is('admin/post/*') || Request::is('admin/add-post') || Request::is('admin/page-metadata') || Request::is('admin/page-metadata/*') ? 'collapse active' : 'collapsed'); ?>"
                    href="#" data-bs-toggle="collapse" data-bs-target="#collapsePost" aria-expanded="false"
                    aria-controls="collapseLayouts">
                    <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
                    Posts
                    <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                </a>
                <div class="collapse <?php echo e(Request::is('admin/add-post') || Request::is('admin/post/*') || Request::is('admin/posts') || Request::is('admin/page-metadata') || Request::is('admin/page-metadata/*') ? 'show' : ''); ?>"
                    id="collapsePost" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                    <nav class="sb-sidenav-menu-nested nav">
                        <a class="nav-link <?php echo e(Request::is('admin/add-post') ? 'active' : ''); ?>"
                            href="<?php echo e(url('admin/add-post')); ?>">Add Post</a>
                        <a class="nav-link <?php echo e(Request::is('admin/posts') || Request::is('admin/post/*') ? 'active' : ''); ?>"
                            href="<?php echo e(url('admin/posts')); ?>">View Posts</a>
                        <a class="nav-link <?php echo e(Request::is('admin/page-metadata') || Request::is('admin/page-metadata/*') ? 'active' : ''); ?>"
                            href="<?php echo e(url('admin/page-metadata')); ?>">Page Metadata</a>
                    </nav>
                </div>
                <a class="nav-link <?php echo e(Request::is('admin/reviews') || Request::is('admin/reviews/*') || Request::is('admin/reviews/create') || Request::is('admin/page-metadata') || Request::is('admin/page-metadata/*') ? 'collapse active' : 'collapsed'); ?>"
                    href="#" data-bs-toggle="collapse" data-bs-target="#collapsereviews" aria-expanded="false"
                    aria-controls="collapseLayouts">
                    <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
                    Review
                    <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                </a>
                <div class="collapse <?php echo e(Request::is('admin/reviews/create') || Request::is('admin/reviews/*') || Request::is('admin/reviews')  ? 'show' : ''); ?>"
                    id="collapsereviews" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                    <nav class="sb-sidenav-menu-nested nav">
                        <a class="nav-link <?php echo e(Request::is('admin/reviews/create') ? 'active' : ''); ?>"
                            href="<?php echo e(url('admin/reviews/create')); ?>">Add Review</a>
                        <a class="nav-link <?php echo e(Request::is('admin/reviews') || Request::is('admin/reviews/*') ? 'active' : ''); ?>"
                            href="<?php echo e(url('admin/reviews')); ?>">ReViews </a>
                    </nav>
                </div>
                <div class="sb-sidenav-menu-heading">Addons</div>
                <a class="nav-link <?php echo e(Request::is('admin/settings') ? 'active' : ''); ?>"
                    href="<?php echo e(url('admin/settings')); ?>">
                    <div class="sb-nav-link-icon"><i class="fas fa-wrench"></i></div>
                    Setting
                </a>
            </div>
        </div>
        <div class="sb-sidenav-footer">
            <div class="small">Logged in as:</div>
            <?php echo e(Auth::user()->name); ?>

        </div>
    </nav>
</div>
<?php /**PATH C:\xampp\htdocs\saurav\briskbrain\resources\views/layouts/inc/admin-sidebar.blade.php ENDPATH**/ ?>